#!/bin/bash
while true; do
php bot.php &>/dev/null&
cd 1 &>/dev/null&
php bot.php &>/dev/null&
cd 
cd cryptotab/2 &>/dev/null&
php bot.php &>/dev/null&
cd 
cd cryptotab/3 &>/dev/null&
php bot.php &>/dev/null&
sleep 5s
done
exit
