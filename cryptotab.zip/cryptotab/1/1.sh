php bot.php
sh 1.sh
